Elf.net Is A Website Similar To Google Santa Tracker Or Norad Santa Tracker!


It is open source and aims to provide a fun and friendly expierence to people of all ages all year long, but mainly in December. The website will eventuall host a Santa Chatbot, games, animations, and maybe even a tracker! It will be a little while before you get there but we will soon.


Have a great holiday season or other 11 months of the year!
Elf.net will be active with the Egg Nog release coming Thanksgiving 2022!]


Copywrite Backyard Inc. and Drop The Mic Studios.